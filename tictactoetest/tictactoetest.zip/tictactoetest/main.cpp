//
//  main.cpp
//  TicTacToe2
//
//  Created by Varun Ved on 4/29/14.
//  Copyright (c) 2014 Varun Ved. All rights reserved.
//
/*

 
 */


#include <iostream>
#include "Board.h"
#include "Board.cpp"
int main(int argc, const char * argv[])
{
    
    // insert code here...
    Board b;
    
    b.set(0, 0, Board::X);
    b.set(0, 1, Board::X);
    b.set(0, 2, Board::X);
    b.set(1, 2, Board::O);
    b.set(1, 3, Board::O);
    b.set(2, 2, Board::O);
    
    Board::Pieces zeroZero = b.pieceAt(0, 0);
    cout << zeroZero;
    
    bool full = b.isFull();
    cout << full;
    
    int mySize = b.getBoardSize();
    return mySize;
    
    Board::Pieces myWinner = b.winner();
    cout <<myWinner;
    
    bool emptyArrayTest = b.isEmpty(0,0);
    cout <<emptyArrayTest;
    
    bool emptyPieceTest = b.isEmpty(Board::X);
    cout <<emptyPieceTest;
    
    bool boardFull = b.isFull();
    cout << boardFull;
    
    cout << b;
    
    
    return 0;
}

