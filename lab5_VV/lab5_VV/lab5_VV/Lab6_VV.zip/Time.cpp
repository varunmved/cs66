/*
 * Time.cpp
 *
 *  Created on: Jan 1, 2014
 *      Author: williamhooper
 
 In C++ the .h file defines the class methods and variables and the .ccp file contains the implementation of the methods. The code was missing the getters and setters for the hours, minutes, etc. and missing the Time(hours, minutes, seconds milli, micro) constructor. In main.ccp line 17 should be Time t; The timeCheck() was good but should have been a private method since it was for the use only inside the class.
 
 */

#include "Time.h"

Time::Time()
{
	
    hours = 1;
    minutes = 1;
    seconds = 1;
    millis = 1;
    micros = 1;
    
    
}

//applying to copy constructor
 Time::Time(const Time& t)
 {
 this -> hours = t.hours;
 this -> minutes = t.minutes;
 this -> seconds = t.seconds;
 this -> millis = t.millis;
 this -> micros = t.micros;
 
 
 }

//constructor for mutliple inputs
Time::Time(int hrs, int mins, int secs, int  mill, int micr)
{
    hours = hrs;
    minutes = mins;
    seconds = secs;
    millis = mill;
    micros = micr;
}

//gets the hours
int Time::getHours()
{
    return hours;
}

//sets the hours based on the input
void Time::setHours(int hrs)
{
    if(hours > 12 && hours <= 23)
    {
        //bool value2 = true;
        Time::set24Hour(true);
        
    }
    else Time::set24Hour(false);
    
    if (hrs > 24)
    {
        cerr << "sorry that's not a valid hour: /n";
        
    }
    else hours = hrs;
}

int Time::getMinutes()
{
    return minutes;
}

void Time::setMinutes(int mins)
{
    if (mins > 60)
    {
        cerr << "sorry that's not a valid minute count: /n";
        
    }
    else minutes = mins;
}

int Time::getSeconds()
{
    return seconds;
}

void Time::setSeconds(int secs)
{
    if (secs > 60)
    {
        cerr << "sorry that's not a valid second count: /n";
        
    }
    else seconds = secs;
}

int Time::getMilli()
{
    return millis;
}

void Time::setMilli(int mill)
{
    if (mill > 1000)
    {
        cerr << "sorry that's not a valid millisecond count: /n";
        
    }
    else millis= mill;
}

int Time::getMicros()
{
    return micros;
}

void Time::setMicros(int micr)
{
    if (micr > 1000)
    {
        cerr << "sorry that's not a valid microsecond count: /n";
        
    }
    else micros = micr;
}

long Time::asLong()
{
    long longTime = (hours*3600000000 + minutes*60000000 + seconds*1000000 + millis*1000) + micros;
    return longTime;
    
}

/**
 * Display as a string
 */


stringstream Time::toString()
{
    stringstream timeString;
    timeString << hours << ":" << minutes << ":" << seconds << ":" << millis << "." << micros;
    return timeString;
    
    
}


/**
 * Enable/disable 24 hour time
 */
void Time::set24Hour(bool value)

{
    isHour = value;
}
/**
 * Return true if 24 hour time is enabled
 */

bool Time::is24Hour()
{
    return true;
}





/**
 * Define ordering relationships
 */
bool operator <(const Time& time1, const Time& time2)
{
    if(time1.hours > time2.hours)
    {
        return false;
    }
        else if(time1.minutes > time2.minutes)
        {
            return false;
        }
        else if(time1.seconds > time2.seconds)
        {
            return false;
        }
        else if(time1.millis > time2.millis)
        {
            return false;
        }
        else if(time1.micros > time2.micros)
        {
            return false;
        }
        else return true;
            
}

bool operator >(const Time& time1, const Time& time2)
{
    if(time1.hours < time2.hours)
    {
        return false;
    }
    else if(time1.minutes < time2.minutes)
    {
        return false;
    }
    else if(time1.seconds < time2.seconds)
    {
        return false;
    }
    else if(time1.millis < time2.millis)
    {
        return false;
    }
    else if(time1.micros < time2.micros)
    {
        return false;
    }
    else return true;
    
    //or couldn't i just say if the > operator is false?

}

bool operator ==(const Time& time1, const Time& time2)
{
    if(time1.hours == time2.hours && time1.minutes == time2.minutes && time1.seconds == time2.seconds && time1.millis == time2.millis && time1.micros == time2.micros)
    {
        return true;
    }
    else return false;
    
}


 // Define addition and subtraction
 
Time operator +(const Time& time2)
{
    
    //how do i get the original value of Time here? so i can add it to the time2 value
    //should i use the variables hrs or hours?
    return Time(time.hrs + time2.hrs, time.mins + time2.mins, time.secs + time2.secs , time.mills +time2.mills, time.micrs + time2.micrs);
}

Time operator -(const Time& time2)
{
    
    //how do i get the original value of Time here? so i can subtract it to the time2 value
    return Time(time.hrs - time2.hrs, time.mins - time2.mins, time.secs - time2.secs , time.mills - time2.mills, time.micrs - time2.micrs);
}

/*
 my confusion with this operator arises from whether it 
 should be a friend or not
 if it's simply a member function, I should have to add 
 Time:: before Time& operator
 


//for this method i'm getting an error that says functions that differ only in their return type
//cannot be overloaded? then why is that I can overload the +/-/< operators?
*/
ostream operator<<(ostream &stream, const Time &time4)
{
    stream << time4;
    return stream;
}

Time& Time::operator =( const Time& rhs )
{
    //add stuff to my assginment operator
    //do i have to set each hrs, mins, secs...
    if(this == &rhs)
    return *this;
}

/*
 
 
 Time::~Time()
 {
 // TODO Auto-generated destructor stub
 }

 
 */