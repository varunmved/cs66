//
//  main.cpp
//  lab4_VV
//
//  Created by Varun Ved on 2/18/14.
//  Copyright (c) 2014 Varun Ved. All rights reserved.

#include <iostream>
#include "Time.h"
//#include "Time.cpp"


int main(int argc, const char * argv[])
{
    
    Time t;
    Time t2(5,4,3,2,1);
    Time t3(6,7,8,9,10);
    Time t4(6,7,8,9,10);
    
    t.setHours(2);
    t.setMinutes(34);
    t.setSeconds(12);
    t.setMilli(321);
    t.setMicros(1);
    long lLength = t.asLong();
    cout << lLength << "\n";
    long l2 = t2.asLong();
    cout << l2 << "\n";
    
    t.operator+(t2);
    t.operator-(t2);
    t.operator=(t3);
    //t.operator >(t2,t3);
    
    stringstream a = t.toString();
    stringstream b = t2.toString();
    
    
    cout << a.str() << "\n";
    cout << b.str();
    //cout<< "\n" << lLength;
    
    
    return 0;
}

