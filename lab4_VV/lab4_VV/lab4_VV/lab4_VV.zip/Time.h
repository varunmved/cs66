/*
 * Time.h
 *
 *  Created on: Jan 1, 2014
 *      Author: williamhooper
 */

#ifndef TIME_H_
#define TIME_H_

#include <iostream>
#include <string>
#include <sstream>


using namespace std;

/**
 * Time class
 *
 * The Time class contains time as hours:minutes:seconds:milliseconds.microseconds.
 */

//const int HOURS = 60;

class Time
{
public:
	Time();
	Time(int hours, int minutes, int seconds, int milli, int micro);
    
    //Time(const Time & t); copy instantiation for the copy assignment 6
	//virtual ~Time(); for assignment 6

	/**
	 * Implement getter and setter methods
	 */

    void timeCheck()
    {
        if(hours > 12 && hours <= 23)
        {
            //bool value2 = true;
            set24Hour(true);
        
        }
        else set24Hour(false);
        
        if (hours > 24)
        {
            cerr << "sorry that's not a valid hour: /n";
            
        }
        else;
        if (minutes > 60)
        {
            cerr << "sorry that's not a valid minute count: /n";
            
        }
        else;
        if (seconds > 60)
        {
            cerr << "sorry that's not a valid second count: /n";
            
        }
        else;
        if (millis > 1000)
        {
            cerr << "sorry that's not a valid millisecond count: /n";
            
        }
        else;
        if (micros > 1000)
        {
            cerr << "sorry that's not a valid microsecond count: /n";
            
        }
        else;
            
    }
    
    
	/**
	 * Return time as a long
	 */
	long asLong()
    {
        long longTime = (hours*3600000000 + minutes*60000000 + seconds*1000000 + millis*1000) + micros;
        return longTime;
        
    }

	/**
	 * Display as a string
	 */
    
    
	stringstream toString()
    {
        stringstream timeString;
        timeString << hours << ":" << minutes << ":" << seconds << ":" << millis << ":" << micros;
        return timeString;
        
        
    }

	
    /**
	 * Enable/disable 24 hour time
	 */
	void set24Hour(bool value)
    
    {
        if(value == true)
        {
            is24Hour();
        }
        if(value == false)
        {
            
        }
    }
    /**
	 * Return true if 24 hour time is enabled
	 */
    
	bool is24Hour()
    {
        return true;
    }
    
    
    // i have no idea what this is.
    
    //friend bool operator <(const Time&, const Time& s);
    
    //Time& operator =( const Time& rhs ); for Assignment 6
    
    /**
     *Define addition and subtraction here
     */
    //Time operator +(const Time&) const;
    //Time operator -(const Time&) const;
    
    

private:
	/**
	 * Private members go here
	 */
    int hours;
    int minutes;
    int seconds;
    int millis;
    int micros;
};

#endif /* TIME_H_ */
