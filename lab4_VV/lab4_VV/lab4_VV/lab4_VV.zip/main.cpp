//
//  main.cpp
//  lab4_VV
//
//  Created by Varun Ved on 2/18/14.
//  Copyright (c) 2014 Varun Ved. All rights reserved.
//

#include <iostream>
#include "Time.h"
//#include "Time.cpp"


int main(int argc, const char * argv[])
{
    
    Time t = *new Time;
    
    //t.set24Hour(true);
    t.timeCheck();
    stringstream a = t.toString();
    long lLength = t.asLong();
    
    
    cout << a.str();
    cout << "\n" << lLength;
    
    
    return 0;
}

