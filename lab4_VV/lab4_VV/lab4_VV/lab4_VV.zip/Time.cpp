/*
 * Time.cpp
 *
 *  Created on: Jan 1, 2014
 *      Author: williamhooper
 */

#include "Time.h"

Time::Time()
{
	
    this -> hours = 12;
    this -> minutes = 5;
    this -> seconds = 3;
    this -> millis = 120;
    this -> micros = 120;
     

}
/*
Time::Time(const Time& t)
{
    this -> hours = t.hours;
    this -> minutes = t.minutes;
    this -> seconds = t.seconds;
    this -> millis = t.millis;
    this -> micros = t.micros;
    
    
}

 
Time::Time(hours, minutes, seconds milli, micro)
{a
    
}


Time::~Time()
{
	// TODO Auto-generated destructor stub
}

long Time::asLong() const
{
    return 0L;
}
*/