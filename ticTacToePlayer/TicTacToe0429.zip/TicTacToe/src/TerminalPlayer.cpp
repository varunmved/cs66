/*
 * TerminalPlayer.cpp
 *
 *  Created on: Apr 22, 2014
 *      Author: williamhooper
 */

#include "TerminalPlayer.h"

TerminalPlayer::TerminalPlayer(string name, Board::Pieces piece,
		Board::Board board) :
		Player(name, piece, board) {
	// TODO Auto-generated constructor stub

}

TerminalPlayer::~TerminalPlayer() {
	// TODO Auto-generated destructor stub
}

