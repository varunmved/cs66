/*
 * ComputerPlayer.cpp
 *
 *  Created on: Apr 22, 2014
 *      Author: williamhooper
 */

#include "ComputerPlayer.h"

ComputerPlayer::ComputerPlayer(string name, Board::Pieces piece,
		Board::Board board) :
		Player(name, piece, board) {
}

ComputerPlayer::~ComputerPlayer() {
	// TODO Auto-generated destructor stub
}

