/*
 * Player.cpp
 *
 *  Created on: Apr 22, 2014
 *      Author: williamhooper
 */

#include "Player.h"

Player::Player(string name, Board::Pieces piece,
		Board::Board board) :
		name(name), piece(piece), board(board) {
	// TODO Auto-generated constructor stub

}

Player::~Player() {
	// TODO Auto-generated destructor stub
}

